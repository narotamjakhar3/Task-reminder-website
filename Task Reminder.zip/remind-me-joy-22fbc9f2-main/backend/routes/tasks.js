/**
 * Task Routes
 * 
 * Defines all API endpoints for task management.
 * All routes require authentication.
 */

const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const taskController = require('../controllers/taskController');

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route   GET /api/tasks
 * @desc    Get all tasks for authenticated user
 * @query   filter (completed|pending|today), category, search
 * @access  Private
 */
router.get('/', taskController.getAllTasks);

/**
 * @route   GET /api/tasks/stats
 * @desc    Get task statistics
 * @access  Private
 */
router.get('/stats', taskController.getTaskStats);

/**
 * @route   GET /api/tasks/:id
 * @desc    Get a single task by ID
 * @access  Private
 */
router.get('/:id', taskController.getTaskById);

/**
 * @route   POST /api/tasks
 * @desc    Create a new task
 * @body    { title, description, due_date, due_time, priority, recurrence, category_id }
 * @access  Private
 */
router.post('/', taskController.createTask);

/**
 * @route   PUT /api/tasks/:id
 * @desc    Update a task
 * @body    { title, description, due_date, due_time, priority, recurrence, category_id, completed }
 * @access  Private
 */
router.put('/:id', taskController.updateTask);

/**
 * @route   PATCH /api/tasks/:id/toggle
 * @desc    Toggle task completion status
 * @access  Private
 */
router.patch('/:id/toggle', taskController.toggleTaskComplete);

/**
 * @route   DELETE /api/tasks/:id
 * @desc    Delete a task
 * @access  Private
 */
router.delete('/:id', taskController.deleteTask);

module.exports = router;
