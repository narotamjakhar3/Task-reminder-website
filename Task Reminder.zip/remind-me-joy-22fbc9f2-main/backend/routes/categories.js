/**
 * Category Routes
 * 
 * Defines all API endpoints for category management.
 * All routes require authentication.
 */

const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const categoryController = require('../controllers/categoryController');

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route   GET /api/categories
 * @desc    Get all categories for authenticated user
 * @access  Private
 */
router.get('/', categoryController.getAllCategories);

/**
 * @route   POST /api/categories
 * @desc    Create a new category
 * @body    { name, color }
 * @access  Private
 */
router.post('/', categoryController.createCategory);

/**
 * @route   PUT /api/categories/:id
 * @desc    Update a category
 * @body    { name, color }
 * @access  Private
 */
router.put('/:id', categoryController.updateCategory);

/**
 * @route   DELETE /api/categories/:id
 * @desc    Delete a category
 * @access  Private
 */
router.delete('/:id', categoryController.deleteCategory);

module.exports = router;
