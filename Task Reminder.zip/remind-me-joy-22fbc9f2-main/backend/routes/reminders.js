/**
 * Reminder Routes
 * 
 * Defines all API endpoints for email reminders.
 * All routes require authentication.
 */

const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const reminderController = require('../controllers/reminderController');

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @route   POST /api/reminders/send
 * @desc    Send a reminder for a single task
 * @body    { taskId, email }
 * @access  Private
 */
router.post('/send', reminderController.sendReminder);

/**
 * @route   POST /api/reminders/send-batch
 * @desc    Send reminders for multiple tasks
 * @body    { taskIds: [], email }
 * @access  Private
 */
router.post('/send-batch', reminderController.sendBatchReminders);

/**
 * @route   GET /api/reminders/due-today
 * @desc    Get all tasks due today (for reminder purposes)
 * @access  Private
 */
router.get('/due-today', reminderController.getTasksDueToday);

/**
 * @route   GET /api/reminders/overdue
 * @desc    Get all overdue tasks
 * @access  Private
 */
router.get('/overdue', reminderController.getOverdueTasks);

module.exports = router;
