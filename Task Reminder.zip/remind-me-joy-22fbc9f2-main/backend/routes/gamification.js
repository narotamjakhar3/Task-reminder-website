/**
 * Gamification Routes
 * 
 * Defines all API endpoints for gamification features.
 * All routes require authentication except leaderboard.
 */

const express = require('express');
const router = express.Router();
const { authenticate, optionalAuth } = require('../middleware/auth');
const gamificationController = require('../controllers/gamificationController');

/**
 * @route   GET /api/gamification/leaderboard
 * @desc    Get top users by points (public)
 * @query   limit (default: 10)
 * @access  Public
 */
router.get('/leaderboard', optionalAuth, gamificationController.getLeaderboard);

// Apply authentication middleware to remaining routes
router.use(authenticate);

/**
 * @route   GET /api/gamification/stats
 * @desc    Get user's gamification stats
 * @access  Private
 */
router.get('/stats', gamificationController.getStats);

/**
 * @route   POST /api/gamification/award
 * @desc    Award points to user
 * @body    { points, reason }
 * @access  Private
 */
router.post('/award', gamificationController.awardPoints);

/**
 * @route   GET /api/gamification/achievements
 * @desc    Get all achievements with user's unlock status
 * @access  Private
 */
router.get('/achievements', gamificationController.getAchievements);

module.exports = router;
