# TaskReminder Backend

Node.js Express backend API for the TaskReminder application.

## Technology Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Database**: PostgreSQL (via Supabase)
- **Authentication**: JWT (via Supabase Auth)
- **Email**: Nodemailer / Resend API

## Project Structure

```
backend/
├── server.js              # Main entry point
├── package.json           # Dependencies and scripts
├── config/
│   └── db.js              # Database configuration
├── controllers/
│   ├── taskController.js      # Task business logic
│   ├── reminderController.js  # Email reminder logic
│   ├── categoryController.js  # Category management
│   └── gamificationController.js # Points & achievements
├── middleware/
│   └── auth.js            # JWT authentication middleware
├── routes/
│   ├── tasks.js           # Task API endpoints
│   ├── reminders.js       # Reminder API endpoints
│   ├── categories.js      # Category API endpoints
│   └── gamification.js    # Gamification API endpoints
├── .env.example           # Environment variables template
└── README.md              # This file
```

## Installation

1. Navigate to the backend folder:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create environment file:
   ```bash
   cp .env.example .env
   ```

4. Edit `.env` with your configuration:
   - Add your Supabase URL and Service Role Key
   - Configure email settings (Resend API or SMTP)

## Running the Server

### Development mode (with auto-reload):
```bash
npm run dev
```

### Production mode:
```bash
npm start
```

The server will start on `http://localhost:5000` (or the PORT specified in .env)

## API Endpoints

### Health Check
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Check API status |

### Tasks
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tasks` | Get all tasks |
| GET | `/api/tasks/:id` | Get single task |
| GET | `/api/tasks/stats` | Get task statistics |
| POST | `/api/tasks` | Create new task |
| PUT | `/api/tasks/:id` | Update task |
| PATCH | `/api/tasks/:id/toggle` | Toggle completion |
| DELETE | `/api/tasks/:id` | Delete task |

### Categories
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/categories` | Get all categories |
| POST | `/api/categories` | Create category |
| PUT | `/api/categories/:id` | Update category |
| DELETE | `/api/categories/:id` | Delete category |

### Reminders
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/reminders/send` | Send single reminder |
| POST | `/api/reminders/send-batch` | Send batch reminders |
| GET | `/api/reminders/due-today` | Get tasks due today |
| GET | `/api/reminders/overdue` | Get overdue tasks |

### Gamification
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/gamification/stats` | Get user stats |
| POST | `/api/gamification/award` | Award points |
| GET | `/api/gamification/achievements` | Get achievements |
| GET | `/api/gamification/leaderboard` | Get leaderboard |

## Authentication

All endpoints (except `/api/health` and `/api/gamification/leaderboard`) require authentication.

Include the JWT token in the Authorization header:
```
Authorization: Bearer <your_jwt_token>
```

## Example Requests

### Create a Task
```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "title": "Complete project",
    "description": "Finish the Node.js backend",
    "due_date": "2024-12-25",
    "priority": "high"
  }'
```

### Get All Tasks
```bash
curl http://localhost:5000/api/tasks \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Send Email Reminder
```bash
curl -X POST http://localhost:5000/api/reminders/send \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "taskId": "task-uuid-here",
    "email": "user@example.com"
  }'
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| PORT | Server port (default: 5000) | No |
| NODE_ENV | Environment (development/production) | No |
| FRONTEND_URL | Frontend URL for CORS | No |
| SUPABASE_URL | Supabase project URL | Yes |
| SUPABASE_SERVICE_ROLE_KEY | Supabase service role key | Yes |
| RESEND_API_KEY | Resend API key for emails | Optional |
| SMTP_HOST | SMTP server host | Optional |
| SMTP_PORT | SMTP server port | Optional |
| SMTP_USER | SMTP username | Optional |
| SMTP_PASS | SMTP password | Optional |
| EMAIL_FROM | Sender email address | No |

## Error Handling

The API returns consistent error responses:

```json
{
  "success": false,
  "error": "Error type",
  "message": "Detailed error message"
}
```

## Contributing

1. Create a feature branch
2. Make your changes
3. Test thoroughly
4. Submit a pull request

## License

ISC
