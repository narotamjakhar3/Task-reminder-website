/**
 * Gamification Controller
 * 
 * Handles gamification features including:
 * - Points management
 * - Streak tracking
 * - Achievements
 */

const { supabase } = require('../config/db');

/**
 * Get user's gamification stats
 */
const getStats = async (req, res) => {
  try {
    const userId = req.userId;

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('total_points, current_streak, longest_streak, tasks_completed_today, last_activity_date')
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    res.json({
      success: true,
      data: {
        totalPoints: profile?.total_points || 0,
        currentStreak: profile?.current_streak || 0,
        longestStreak: profile?.longest_streak || 0,
        tasksCompletedToday: profile?.tasks_completed_today || 0,
        lastActivityDate: profile?.last_activity_date
      }
    });
  } catch (error) {
    console.error('Error fetching gamification stats:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch stats',
      message: error.message
    });
  }
};

/**
 * Award points to user
 */
const awardPoints = async (req, res) => {
  try {
    const userId = req.userId;
    const { points, reason } = req.body;

    if (!points || points <= 0) {
      return res.status(400).json({
        success: false,
        error: 'Valid points amount is required'
      });
    }

    // Get current profile
    const { data: profile, error: fetchError } = await supabase
      .from('profiles')
      .select('total_points, current_streak, longest_streak, tasks_completed_today, last_activity_date')
      .eq('user_id', userId)
      .single();

    if (fetchError) throw fetchError;

    const today = new Date().toISOString().split('T')[0];
    const lastActivity = profile?.last_activity_date;
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    // Calculate new streak
    let newStreak = profile?.current_streak || 0;
    let tasksToday = profile?.tasks_completed_today || 0;

    if (lastActivity === today) {
      tasksToday += 1;
    } else if (lastActivity === yesterday) {
      newStreak += 1;
      tasksToday = 1;
    } else if (lastActivity !== today) {
      newStreak = 1;
      tasksToday = 1;
    }

    const longestStreak = Math.max(newStreak, profile?.longest_streak || 0);

    // Update profile
    const { data, error } = await supabase
      .from('profiles')
      .update({
        total_points: (profile?.total_points || 0) + points,
        current_streak: newStreak,
        longest_streak: longestStreak,
        tasks_completed_today: tasksToday,
        last_activity_date: today
      })
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;

    // Check for new achievements
    const unlockedAchievements = await checkAchievements(userId, data);

    res.json({
      success: true,
      message: `Awarded ${points} points`,
      data: {
        totalPoints: data.total_points,
        currentStreak: data.current_streak,
        longestStreak: data.longest_streak,
        tasksCompletedToday: data.tasks_completed_today,
        newAchievements: unlockedAchievements
      }
    });
  } catch (error) {
    console.error('Error awarding points:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to award points',
      message: error.message
    });
  }
};

/**
 * Check and unlock achievements
 */
const checkAchievements = async (userId, profile) => {
  try {
    // Get all achievements
    const { data: achievements, error: achError } = await supabase
      .from('achievements')
      .select('*');

    if (achError) throw achError;

    // Get user's unlocked achievements
    const { data: unlockedIds, error: unlockError } = await supabase
      .from('user_achievements')
      .select('achievement_id')
      .eq('user_id', userId);

    if (unlockError) throw unlockError;

    const unlockedSet = new Set(unlockedIds?.map(u => u.achievement_id) || []);
    const newlyUnlocked = [];

    // Check each achievement
    for (const achievement of achievements || []) {
      if (unlockedSet.has(achievement.id)) continue;

      let shouldUnlock = false;

      if (achievement.points_required && profile.total_points >= achievement.points_required) {
        shouldUnlock = true;
      }
      if (achievement.streak_required && profile.current_streak >= achievement.streak_required) {
        shouldUnlock = true;
      }
      if (achievement.tasks_required && profile.tasks_completed_today >= achievement.tasks_required) {
        shouldUnlock = true;
      }

      if (shouldUnlock) {
        await supabase.from('user_achievements').insert({
          user_id: userId,
          achievement_id: achievement.id
        });
        newlyUnlocked.push(achievement);
      }
    }

    return newlyUnlocked;
  } catch (error) {
    console.error('Error checking achievements:', error);
    return [];
  }
};

/**
 * Get all achievements with unlock status
 */
const getAchievements = async (req, res) => {
  try {
    const userId = req.userId;

    // Get all achievements
    const { data: achievements, error: achError } = await supabase
      .from('achievements')
      .select('*')
      .order('points_required', { ascending: true });

    if (achError) throw achError;

    // Get user's unlocked achievements
    const { data: userAchievements, error: unlockError } = await supabase
      .from('user_achievements')
      .select('achievement_id, unlocked_at')
      .eq('user_id', userId);

    if (unlockError) throw unlockError;

    const unlockedMap = new Map(
      userAchievements?.map(ua => [ua.achievement_id, ua.unlocked_at]) || []
    );

    // Combine data
    const achievementsWithStatus = achievements?.map(ach => ({
      ...ach,
      unlocked: unlockedMap.has(ach.id),
      unlockedAt: unlockedMap.get(ach.id) || null
    })) || [];

    res.json({
      success: true,
      data: achievementsWithStatus
    });
  } catch (error) {
    console.error('Error fetching achievements:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch achievements',
      message: error.message
    });
  }
};

/**
 * Get leaderboard (top users by points)
 */
const getLeaderboard = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;

    const { data, error } = await supabase
      .from('profiles')
      .select('display_name, total_points, current_streak, longest_streak')
      .order('total_points', { ascending: false })
      .limit(limit);

    if (error) throw error;

    res.json({
      success: true,
      data: data.map((user, index) => ({
        rank: index + 1,
        displayName: user.display_name || 'Anonymous',
        totalPoints: user.total_points,
        currentStreak: user.current_streak,
        longestStreak: user.longest_streak
      }))
    });
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch leaderboard',
      message: error.message
    });
  }
};

module.exports = {
  getStats,
  awardPoints,
  getAchievements,
  getLeaderboard
};
