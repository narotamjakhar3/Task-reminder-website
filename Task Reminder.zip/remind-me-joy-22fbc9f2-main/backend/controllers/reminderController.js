/**
 * Reminder Controller
 * 
 * Handles email reminder functionality including:
 * - Sending email reminders for tasks
 * - Getting tasks due today for reminders
 * - Batch reminder sending
 */

const nodemailer = require('nodemailer');
const { supabase } = require('../config/db');

// Create email transporter
// Note: For production, use a proper email service like SendGrid, Resend, or AWS SES
const createTransporter = () => {
  // Check if using Resend API
  if (process.env.RESEND_API_KEY) {
    return {
      type: 'resend',
      apiKey: process.env.RESEND_API_KEY
    };
  }

  // Fallback to SMTP (for development/testing)
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
};

/**
 * Send email using Resend API
 */
const sendWithResend = async (to, subject, html) => {
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM || 'TaskReminder <onboarding@resend.dev>',
      to: [to],
      subject,
      html
    })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to send email');
  }

  return response.json();
};

/**
 * Send a single task reminder email
 */
const sendReminder = async (req, res) => {
  try {
    const { taskId, email } = req.body;
    const userId = req.userId;

    // Validate input
    if (!taskId || !email) {
      return res.status(400).json({
        success: false,
        error: 'Task ID and email are required'
      });
    }

    // Get task details
    const { data: task, error: taskError } = await supabase
      .from('tasks')
      .select('*')
      .eq('id', taskId)
      .eq('user_id', userId)
      .single();

    if (taskError || !task) {
      return res.status(404).json({
        success: false,
        error: 'Task not found'
      });
    }

    // Prepare email content
    const subject = `Reminder: ${task.title}`;
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Task Reminder</h2>
        <div style="background: #f5f5f5; padding: 20px; border-radius: 8px;">
          <h3 style="margin-top: 0;">${task.title}</h3>
          ${task.description ? `<p>${task.description}</p>` : ''}
          <p><strong>Due Date:</strong> ${task.due_date}</p>
          ${task.due_time ? `<p><strong>Time:</strong> ${task.due_time}</p>` : ''}
          <p><strong>Priority:</strong> <span style="text-transform: capitalize;">${task.priority}</span></p>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 20px;">
          This reminder was sent from TaskReminder App.
        </p>
      </div>
    `;

    // Send email
    if (process.env.RESEND_API_KEY) {
      await sendWithResend(email, subject, html);
    } else {
      const transporter = createTransporter();
      await transporter.sendMail({
        from: process.env.EMAIL_FROM || 'TaskReminder <noreply@taskreminder.com>',
        to: email,
        subject,
        html
      });
    }

    res.json({
      success: true,
      message: 'Reminder sent successfully'
    });
  } catch (error) {
    console.error('Error sending reminder:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to send reminder',
      message: error.message
    });
  }
};

/**
 * Send reminders for multiple tasks
 */
const sendBatchReminders = async (req, res) => {
  try {
    const { taskIds, email } = req.body;
    const userId = req.userId;

    if (!taskIds || !Array.isArray(taskIds) || taskIds.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Task IDs array is required'
      });
    }

    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Email is required'
      });
    }

    // Get tasks
    const { data: tasks, error } = await supabase
      .from('tasks')
      .select('*')
      .in('id', taskIds)
      .eq('user_id', userId);

    if (error) throw error;

    if (tasks.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No tasks found'
      });
    }

    // Prepare batch email
    const subject = `Task Reminders (${tasks.length} tasks)`;
    const taskListHtml = tasks.map(task => `
      <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 10px;">
        <h4 style="margin: 0 0 10px 0;">${task.title}</h4>
        ${task.description ? `<p style="margin: 5px 0;">${task.description}</p>` : ''}
        <p style="margin: 5px 0;"><strong>Due:</strong> ${task.due_date} ${task.due_time || ''}</p>
        <p style="margin: 5px 0;"><strong>Priority:</strong> ${task.priority}</p>
      </div>
    `).join('');

    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #333;">Your Task Reminders</h2>
        <p>You have ${tasks.length} pending task(s):</p>
        ${taskListHtml}
        <p style="color: #666; font-size: 12px; margin-top: 20px;">
          This reminder was sent from TaskReminder App.
        </p>
      </div>
    `;

    // Send email
    if (process.env.RESEND_API_KEY) {
      await sendWithResend(email, subject, html);
    } else {
      const transporter = createTransporter();
      await transporter.sendMail({
        from: process.env.EMAIL_FROM || 'TaskReminder <noreply@taskreminder.com>',
        to: email,
        subject,
        html
      });
    }

    res.json({
      success: true,
      message: `Reminders sent for ${tasks.length} tasks`
    });
  } catch (error) {
    console.error('Error sending batch reminders:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to send reminders',
      message: error.message
    });
  }
};

/**
 * Get tasks due today (for reminder purposes)
 */
const getTasksDueToday = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', userId)
      .eq('due_date', today)
      .eq('completed', false)
      .order('due_time', { ascending: true });

    if (error) throw error;

    res.json({
      success: true,
      count: data.length,
      data: data
    });
  } catch (error) {
    console.error('Error fetching tasks due today:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch tasks',
      message: error.message
    });
  }
};

/**
 * Get overdue tasks
 */
const getOverdueTasks = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', userId)
      .lt('due_date', today)
      .eq('completed', false)
      .order('due_date', { ascending: true });

    if (error) throw error;

    res.json({
      success: true,
      count: data.length,
      data: data
    });
  } catch (error) {
    console.error('Error fetching overdue tasks:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch tasks',
      message: error.message
    });
  }
};

module.exports = {
  sendReminder,
  sendBatchReminders,
  getTasksDueToday,
  getOverdueTasks
};
