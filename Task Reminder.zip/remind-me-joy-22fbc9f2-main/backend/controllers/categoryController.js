/**
 * Category Controller
 * 
 * Handles category management including:
 * - CRUD operations for task categories
 */

const { supabase } = require('../config/db');

/**
 * Get all categories for the authenticated user
 */
const getAllCategories = async (req, res) => {
  try {
    const userId = req.userId;

    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('user_id', userId)
      .order('name', { ascending: true });

    if (error) throw error;

    res.json({
      success: true,
      count: data.length,
      data: data
    });
  } catch (error) {
    console.error('Error fetching categories:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch categories',
      message: error.message
    });
  }
};

/**
 * Create a new category
 */
const createCategory = async (req, res) => {
  try {
    const userId = req.userId;
    const { name, color } = req.body;

    if (!name) {
      return res.status(400).json({
        success: false,
        error: 'Category name is required'
      });
    }

    const { data, error } = await supabase
      .from('categories')
      .insert({
        user_id: userId,
        name,
        color: color || '#6366f1'
      })
      .select()
      .single();

    if (error) throw error;

    res.status(201).json({
      success: true,
      message: 'Category created successfully',
      data: data
    });
  } catch (error) {
    console.error('Error creating category:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to create category',
      message: error.message
    });
  }
};

/**
 * Update a category
 */
const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;
    const { name, color } = req.body;

    const updates = {};
    if (name) updates.name = name;
    if (color) updates.color = color;

    const { data, error } = await supabase
      .from('categories')
      .update(updates)
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({
          success: false,
          error: 'Category not found'
        });
      }
      throw error;
    }

    res.json({
      success: true,
      message: 'Category updated successfully',
      data: data
    });
  } catch (error) {
    console.error('Error updating category:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update category',
      message: error.message
    });
  }
};

/**
 * Delete a category
 */
const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;

    // First, remove category from tasks
    await supabase
      .from('tasks')
      .update({ category_id: null })
      .eq('category_id', id)
      .eq('user_id', userId);

    // Then delete the category
    const { error } = await supabase
      .from('categories')
      .delete()
      .eq('id', id)
      .eq('user_id', userId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Category deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting category:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete category',
      message: error.message
    });
  }
};

module.exports = {
  getAllCategories,
  createCategory,
  updateCategory,
  deleteCategory
};
