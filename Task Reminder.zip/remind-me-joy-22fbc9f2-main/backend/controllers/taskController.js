/**
 * Task Controller
 * 
 * Handles all task-related business logic including:
 * - CRUD operations for tasks
 * - Task filtering and searching
 * - Task completion and recurring task handling
 */

const { supabase } = require('../config/db');

/**
 * Get all tasks for the authenticated user
 */
const getAllTasks = async (req, res) => {
  try {
    const userId = req.userId;
    const { filter, category, search } = req.query;

    let query = supabase
      .from('tasks')
      .select('*, categories(id, name, color)')
      .eq('user_id', userId)
      .order('due_date', { ascending: true });

    // Apply filters
    if (filter === 'completed') {
      query = query.eq('completed', true);
    } else if (filter === 'pending') {
      query = query.eq('completed', false);
    } else if (filter === 'today') {
      const today = new Date().toISOString().split('T')[0];
      query = query.eq('due_date', today).eq('completed', false);
    }

    // Filter by category
    if (category) {
      query = query.eq('category_id', category);
    }

    // Search by title
    if (search) {
      query = query.ilike('title', `%${search}%`);
    }

    const { data, error } = await query;

    if (error) throw error;

    res.json({
      success: true,
      count: data.length,
      data: data
    });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch tasks',
      message: error.message
    });
  }
};

/**
 * Get a single task by ID
 */
const getTaskById = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;

    const { data, error } = await supabase
      .from('tasks')
      .select('*, categories(id, name, color), subtasks(*)')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({ 
          success: false,
          error: 'Task not found'
        });
      }
      throw error;
    }

    res.json({
      success: true,
      data: data
    });
  } catch (error) {
    console.error('Error fetching task:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch task',
      message: error.message
    });
  }
};

/**
 * Create a new task
 */
const createTask = async (req, res) => {
  try {
    const userId = req.userId;
    const { title, description, due_date, due_time, priority, recurrence, category_id } = req.body;

    // Validate required fields
    if (!title || !due_date) {
      return res.status(400).json({
        success: false,
        error: 'Title and due date are required'
      });
    }

    const { data, error } = await supabase
      .from('tasks')
      .insert({
        user_id: userId,
        title,
        description: description || null,
        due_date,
        due_time: due_time || null,
        priority: priority || 'medium',
        recurrence: recurrence || 'none',
        category_id: category_id || null,
        completed: false
      })
      .select()
      .single();

    if (error) throw error;

    res.status(201).json({
      success: true,
      message: 'Task created successfully',
      data: data
    });
  } catch (error) {
    console.error('Error creating task:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to create task',
      message: error.message
    });
  }
};

/**
 * Update an existing task
 */
const updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;
    const updates = req.body;

    // Remove fields that shouldn't be updated directly
    delete updates.id;
    delete updates.user_id;
    delete updates.created_at;

    const { data, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({ 
          success: false,
          error: 'Task not found'
        });
      }
      throw error;
    }

    res.json({
      success: true,
      message: 'Task updated successfully',
      data: data
    });
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to update task',
      message: error.message
    });
  }
};

/**
 * Toggle task completion status
 */
const toggleTaskComplete = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;

    // First get the current task
    const { data: task, error: fetchError } = await supabase
      .from('tasks')
      .select('*')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (fetchError) {
      if (fetchError.code === 'PGRST116') {
        return res.status(404).json({ 
          success: false,
          error: 'Task not found'
        });
      }
      throw fetchError;
    }

    // Toggle completion
    const { data, error } = await supabase
      .from('tasks')
      .update({ completed: !task.completed })
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;

    // Handle recurring tasks - create next occurrence if task is completed
    if (!task.completed && task.recurrence !== 'none') {
      await createNextRecurrence(task, userId);
    }

    res.json({
      success: true,
      message: `Task marked as ${data.completed ? 'completed' : 'pending'}`,
      data: data
    });
  } catch (error) {
    console.error('Error toggling task:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to toggle task',
      message: error.message
    });
  }
};

/**
 * Create next occurrence for recurring tasks
 */
const createNextRecurrence = async (task, userId) => {
  const currentDate = new Date(task.due_date);
  let nextDate;

  switch (task.recurrence) {
    case 'daily':
      nextDate = new Date(currentDate.setDate(currentDate.getDate() + 1));
      break;
    case 'weekly':
      nextDate = new Date(currentDate.setDate(currentDate.getDate() + 7));
      break;
    case 'monthly':
      nextDate = new Date(currentDate.setMonth(currentDate.getMonth() + 1));
      break;
    default:
      return;
  }

  await supabase.from('tasks').insert({
    user_id: userId,
    title: task.title,
    description: task.description,
    due_date: nextDate.toISOString().split('T')[0],
    due_time: task.due_time,
    priority: task.priority,
    recurrence: task.recurrence,
    category_id: task.category_id,
    completed: false
  });
};

/**
 * Delete a task
 */
const deleteTask = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.userId;

    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', id)
      .eq('user_id', userId);

    if (error) throw error;

    res.json({
      success: true,
      message: 'Task deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to delete task',
      message: error.message
    });
  }
};

/**
 * Get task statistics for the user
 */
const getTaskStats = async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date().toISOString().split('T')[0];

    // Get all tasks
    const { data: tasks, error } = await supabase
      .from('tasks')
      .select('completed, due_date')
      .eq('user_id', userId);

    if (error) throw error;

    const stats = {
      total: tasks.length,
      completed: tasks.filter(t => t.completed).length,
      pending: tasks.filter(t => !t.completed).length,
      dueToday: tasks.filter(t => t.due_date === today && !t.completed).length,
      overdue: tasks.filter(t => t.due_date < today && !t.completed).length
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ 
      success: false,
      error: 'Failed to fetch statistics',
      message: error.message
    });
  }
};

module.exports = {
  getAllTasks,
  getTaskById,
  createTask,
  updateTask,
  toggleTaskComplete,
  deleteTask,
  getTaskStats
};
