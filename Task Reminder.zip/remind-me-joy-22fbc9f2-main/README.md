# TaskReminder - Full Stack Application

A complete task management application built with **React.js** (Frontend) and **Node.js Express** (Backend).

## 📁 Project Structure

```
taskreminder/
├── 📂 src/                    # React.js Frontend
│   ├── components/            # React components
│   ├── hooks/                 # Custom React hooks
│   ├── pages/                 # Page components
│   └── integrations/          # API integrations
├── 📂 backend/                # Node.js Backend
│   ├── server.js              # Express server entry
│   ├── routes/                # API route definitions
│   ├── controllers/           # Business logic
│   ├── middleware/            # Express middleware
│   └── config/                # Configuration files
├── 📂 public/                 # Static assets
└── package.json               # Frontend dependencies
```

## 🛠️ Technology Stack

### Frontend (React.js)
- React.js 18, Vite, TypeScript, Tailwind CSS, shadcn/ui, React Query, React Router

### Backend (Node.js)
- Node.js, Express.js, Supabase JS, Nodemailer, JWT, CORS

## 🚀 Getting Started

### Frontend
```bash
npm install
npm run dev
```
Runs on: `http://localhost:5173`

### Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your credentials
npm run dev
```
Runs on: `http://localhost:5000`

## 📡 API Endpoints

| Category | Endpoint | Method | Description |
|----------|----------|--------|-------------|
| Tasks | `/api/tasks` | GET/POST | List/Create tasks |
| Tasks | `/api/tasks/:id` | GET/PUT/DELETE | Single task ops |
| Categories | `/api/categories` | GET/POST | List/Create categories |
| Reminders | `/api/reminders/send` | POST | Send email reminder |
| Gamification | `/api/gamification/stats` | GET | User stats |

See `backend/README.md` for full API documentation.
