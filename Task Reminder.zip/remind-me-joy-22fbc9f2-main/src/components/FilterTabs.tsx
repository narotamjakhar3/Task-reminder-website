import { FilterType } from "@/types/task";
import { cn } from "@/lib/utils";
import { List, CalendarDays, CalendarClock, CheckCircle2 } from "lucide-react";

interface FilterTabsProps {
  filter: FilterType;
  onChange: (filter: FilterType) => void;
  counts: {
    all: number;
    today: number;
    upcoming: number;
    completed: number;
  };
}

const filters: { value: FilterType; label: string; icon: typeof List }[] = [
  { value: "all", label: "All Tasks", icon: List },
  { value: "today", label: "Today", icon: CalendarDays },
  { value: "upcoming", label: "Upcoming", icon: CalendarClock },
  { value: "completed", label: "Completed", icon: CheckCircle2 },
];

export const FilterTabs = ({ filter, onChange, counts }: FilterTabsProps) => {
  return (
    <div className="flex flex-wrap gap-2">
      {filters.map(({ value, label, icon: Icon }) => (
        <button
          key={value}
          onClick={() => onChange(value)}
          className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
            filter === value
              ? "bg-primary text-primary-foreground shadow-card"
              : "bg-card text-muted-foreground hover:bg-secondary hover:text-foreground"
          )}
        >
          <Icon className="h-4 w-4" />
          {label}
          <span
            className={cn(
              "ml-1 px-1.5 py-0.5 rounded-full text-xs",
              filter === value
                ? "bg-primary-foreground/20 text-primary-foreground"
                : "bg-muted text-muted-foreground"
            )}
          >
            {counts[value]}
          </span>
        </button>
      ))}
    </div>
  );
};
