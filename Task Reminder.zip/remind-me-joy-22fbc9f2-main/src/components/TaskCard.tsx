import { useState } from "react";
import { Task, Category } from "@/types/task";
import { format, isToday, isTomorrow, isPast, parseISO } from "date-fns";
import { Check, Clock, Trash2, AlertCircle, Edit2, RefreshCw, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { SubtaskList } from "@/components/SubtaskList";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface TaskCardProps {
  task: Task;
  userId: string | null;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
  onSubtaskComplete?: () => void;
}

const priorityStyles = {
  high: "border-l-priority-high bg-priority-high/5",
  medium: "border-l-priority-medium bg-priority-medium/5",
  low: "border-l-priority-low bg-priority-low/5",
};

const priorityBadgeStyles = {
  high: "bg-priority-high/10 text-priority-high",
  medium: "bg-priority-medium/10 text-priority-medium",
  low: "bg-priority-low/10 text-priority-low",
};

export const TaskCard = ({ task, userId, onToggle, onDelete, onEdit, onSubtaskComplete }: TaskCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const dueDate = parseISO(task.due_date);
  const isOverdue = isPast(dueDate) && !task.completed && !isToday(dueDate);
  
  const formatDueDate = () => {
    if (isToday(dueDate)) return "Today";
    if (isTomorrow(dueDate)) return "Tomorrow";
    return format(dueDate, "MMM d, yyyy");
  };

  return (
    <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
      <div
        className={cn(
          "group relative bg-card rounded-lg border-l-4 shadow-card transition-all duration-200 hover:shadow-card-hover animate-fade-in",
          task.completed ? "border-l-muted opacity-60" : priorityStyles[task.priority]
        )}
      >
        <div className="p-4">
          <div className="flex items-start gap-3">
            <button
              onClick={() => onToggle(task.id)}
              className={cn(
                "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-all",
                task.completed
                  ? "border-primary bg-primary text-primary-foreground animate-check-bounce"
                  : "border-muted-foreground/30 hover:border-primary"
              )}
            >
              {task.completed && <Check className="h-3 w-3" />}
            </button>

            <div className="flex-1 min-w-0">
              <h3
                className={cn(
                  "font-medium text-foreground transition-all",
                  task.completed && "line-through text-muted-foreground"
                )}
              >
                {task.title}
              </h3>
              
              {task.description && (
                <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                  {task.description}
                </p>
              )}

              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
                    isOverdue ? "bg-destructive/10 text-destructive" : "bg-secondary text-secondary-foreground"
                  )}
                >
                  {isOverdue && <AlertCircle className="h-3 w-3" />}
                  <Clock className="h-3 w-3" />
                  {formatDueDate()}
                  {task.due_time && ` at ${task.due_time}`}
                </span>

                <span
                  className={cn(
                    "rounded-full px-2 py-0.5 text-xs font-medium capitalize",
                    priorityBadgeStyles[task.priority]
                  )}
                >
                  {task.priority}
                </span>

                {task.recurrence !== "none" && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground">
                    <RefreshCw className="h-3 w-3" />
                    {task.recurrence}
                  </span>
                )}

                {task.category && (
                  <span
                    className="rounded-full px-2 py-0.5 text-xs font-medium"
                    style={{ backgroundColor: `${task.category.color}20`, color: task.category.color }}
                  >
                    {task.category.name}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1">
              <CollapsibleTrigger asChild>
                <button
                  className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition-all"
                >
                  {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </button>
              </CollapsibleTrigger>
              <button
                onClick={() => onEdit(task)}
                className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary transition-all opacity-0 group-hover:opacity-100"
              >
                <Edit2 className="h-4 w-4" />
              </button>
              <button
                onClick={() => onDelete(task.id)}
                className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all opacity-0 group-hover:opacity-100"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        <CollapsibleContent>
          <div className="px-4 pb-4 pt-0 border-t border-border/50">
            <div className="pt-3">
              <p className="text-xs font-medium text-muted-foreground mb-2">Subtasks</p>
              <SubtaskList 
                userId={userId} 
                taskId={task.id} 
                onSubtaskComplete={onSubtaskComplete}
              />
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
};
