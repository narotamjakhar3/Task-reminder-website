import { Flame, Trophy, Star, Award, Crown, Zap, Medal, Coins, Gem, Diamond } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Progress } from "@/components/ui/progress";
import { useGamification, Achievement } from "@/hooks/useGamification";

interface GamificationPanelProps {
  userId: string | null;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  trophy: Trophy,
  star: Star,
  award: Award,
  crown: Crown,
  flame: Flame,
  zap: Zap,
  medal: Medal,
  coins: Coins,
  gem: Gem,
  diamond: Diamond,
};

export const GamificationPanel = ({ userId }: GamificationPanelProps) => {
  const { stats, achievements, unlockedAchievementIds, loading } = useGamification(userId);

  const getIcon = (iconName: string) => {
    const IconComponent = iconMap[iconName] || Trophy;
    return IconComponent;
  };

  const getNextMilestone = () => {
    const pointMilestones = [100, 500, 1000];
    const nextPoints = pointMilestones.find((m) => m > stats.total_points) || 1000;
    return { points: nextPoints, progress: (stats.total_points / nextPoints) * 100 };
  };

  const milestone = getNextMilestone();

  if (loading) {
    return null;
  }

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Trophy className="h-4 w-4 text-amber-500" />
          <span className="font-semibold">{stats.total_points}</span>
          {stats.current_streak > 0 && (
            <>
              <span className="text-muted-foreground">•</span>
              <Flame className="h-4 w-4 text-orange-500" />
              <span>{stats.current_streak}</span>
            </>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            Your Progress
          </SheetTitle>
          <SheetDescription>
            Track your achievements and streaks
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 rounded-xl p-4 border border-amber-500/20">
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 mb-2">
                <Trophy className="h-5 w-5" />
                <span className="text-sm font-medium">Total Points</span>
              </div>
              <p className="text-3xl font-bold">{stats.total_points}</p>
            </div>

            <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-xl p-4 border border-orange-500/20">
              <div className="flex items-center gap-2 text-orange-600 dark:text-orange-400 mb-2">
                <Flame className="h-5 w-5" />
                <span className="text-sm font-medium">Current Streak</span>
              </div>
              <p className="text-3xl font-bold">{stats.current_streak} days</p>
              <p className="text-xs text-muted-foreground mt-1">
                Best: {stats.longest_streak} days
              </p>
            </div>
          </div>

          {/* Progress to next milestone */}
          <div className="bg-card rounded-xl p-4 border">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Next Milestone</span>
              <span className="text-sm text-muted-foreground">
                {stats.total_points} / {milestone.points}
              </span>
            </div>
            <Progress value={milestone.progress} className="h-2" />
          </div>

          {/* Achievements */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Achievements</h3>
            <div className="grid gap-3">
              {achievements.map((achievement) => {
                const IconComponent = getIcon(achievement.icon);
                const isUnlocked = unlockedAchievementIds.includes(achievement.id);
                
                return (
                  <div
                    key={achievement.id}
                    className={cn(
                      "flex items-center gap-4 p-4 rounded-xl border transition-all",
                      isUnlocked
                        ? "bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20"
                        : "bg-muted/30 border-border opacity-60"
                    )}
                  >
                    <div
                      className={cn(
                        "flex h-12 w-12 items-center justify-center rounded-full",
                        isUnlocked
                          ? "bg-primary/10 text-primary"
                          : "bg-muted text-muted-foreground"
                      )}
                    >
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{achievement.name}</h4>
                        {isUnlocked && (
                          <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                            Unlocked
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {achievement.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};
