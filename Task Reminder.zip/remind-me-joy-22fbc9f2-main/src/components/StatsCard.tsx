import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  color: "primary" | "success" | "warning" | "muted";
  delay?: number;
}

const colorStyles = {
  primary: "bg-primary/10 text-primary",
  success: "bg-priority-low/10 text-priority-low",
  warning: "bg-priority-medium/10 text-priority-medium",
  muted: "bg-muted text-muted-foreground",
};

export const StatsCard = ({ title, value, icon: Icon, color, delay = 0 }: StatsCardProps) => {
  return (
    <div
      className="bg-card rounded-xl p-5 shadow-card transition-all hover:shadow-card-hover animate-fade-in"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold mt-1">{value}</p>
        </div>
        <div className={cn("p-3 rounded-xl", colorStyles[color])}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
    </div>
  );
};
