import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Mail, Loader2, Send, CheckCircle } from "lucide-react";
import { Task } from "@/types/task";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format, parseISO } from "date-fns";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";

interface EmailReminderProps {
  tasks: Task[];
  userEmail: string;
}

export function EmailReminder({ tasks, userEmail }: EmailReminderProps) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
  const [sentTasks, setSentTasks] = useState<string[]>([]);

  const pendingTasks = tasks.filter(t => !t.completed);

  const toggleTask = (taskId: string) => {
    setSelectedTasks(prev => 
      prev.includes(taskId) 
        ? prev.filter(id => id !== taskId)
        : [...prev, taskId]
    );
  };

  const selectAll = () => {
    if (selectedTasks.length === pendingTasks.length) {
      setSelectedTasks([]);
    } else {
      setSelectedTasks(pendingTasks.map(t => t.id));
    }
  };

  const sendReminders = async () => {
    if (selectedTasks.length === 0) {
      toast.error("Please select at least one task");
      return;
    }

    setSending(true);
    const tasksToSend = pendingTasks.filter(t => selectedTasks.includes(t.id));
    
    let successCount = 0;
    const newSentTasks: string[] = [];

    for (const task of tasksToSend) {
      try {
        const { error } = await supabase.functions.invoke("send-reminder", {
          body: {
            email: userEmail,
            taskTitle: task.title,
            dueDate: format(parseISO(task.due_date), "MMM d, yyyy"),
            dueTime: task.due_time,
            priority: task.priority
          }
        });

        if (error) throw error;
        successCount++;
        newSentTasks.push(task.id);
      } catch (err) {
        console.error("Failed to send reminder for:", task.title, err);
      }
    }

    setSentTasks(prev => [...prev, ...newSentTasks]);
    setSelectedTasks([]);
    setSending(false);

    if (successCount === tasksToSend.length) {
      toast.success(`Sent ${successCount} reminder${successCount > 1 ? "s" : ""} to ${userEmail}`);
    } else if (successCount > 0) {
      toast.warning(`Sent ${successCount}/${tasksToSend.length} reminders`);
    } else {
      toast.error("Failed to send reminders. Check your Resend configuration.");
    }
  };

  const priorityColors = {
    high: "border-l-destructive",
    medium: "border-l-yellow-500",
    low: "border-l-green-500"
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Mail className="h-4 w-4" />
          Email Reminders
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-primary" />
            Send Email Reminders
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          <p className="text-sm text-muted-foreground">
            Select tasks to send reminders to <span className="font-medium text-foreground">{userEmail}</span>
          </p>

          {pendingTasks.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>All tasks completed!</p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <Button variant="ghost" size="sm" onClick={selectAll}>
                  {selectedTasks.length === pendingTasks.length ? "Deselect All" : "Select All"}
                </Button>
                <span className="text-sm text-muted-foreground">
                  {selectedTasks.length} selected
                </span>
              </div>

              <ScrollArea className="h-[300px] pr-4">
                <div className="space-y-2">
                  {pendingTasks.map(task => (
                    <div
                      key={task.id}
                      className={`flex items-center gap-3 p-3 rounded-lg border border-l-4 ${priorityColors[task.priority]} bg-card hover:bg-accent/50 transition-colors cursor-pointer`}
                      onClick={() => toggleTask(task.id)}
                    >
                      <Checkbox 
                        checked={selectedTasks.includes(task.id)}
                        onCheckedChange={() => toggleTask(task.id)}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{task.title}</p>
                        <p className="text-xs text-muted-foreground">
                          Due: {format(parseISO(task.due_date), "MMM d")}
                          {task.due_time && ` at ${task.due_time}`}
                        </p>
                      </div>
                      {sentTasks.includes(task.id) && (
                        <CheckCircle className="h-4 w-4 text-green-500 shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <Button 
                onClick={sendReminders} 
                disabled={sending || selectedTasks.length === 0}
                className="w-full"
              >
                {sending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Send className="h-4 w-4 mr-2" />
                )}
                Send {selectedTasks.length > 0 ? `${selectedTasks.length} ` : ""}Reminder{selectedTasks.length !== 1 ? "s" : ""}
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
