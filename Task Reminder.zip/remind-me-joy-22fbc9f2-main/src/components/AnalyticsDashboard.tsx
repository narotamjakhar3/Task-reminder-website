import { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { BarChart3, TrendingUp, PieChart as PieChartIcon, Calendar } from "lucide-react";
import { Task } from "@/types/task";
import { Category } from "@/types/task";
import { 
  PieChart, Pie, Cell, 
  BarChart, Bar, XAxis, YAxis, Tooltip, 
  ResponsiveContainer, Legend,
  LineChart, Line, CartesianGrid
} from "recharts";
import { format, parseISO, startOfWeek, eachDayOfInterval, subDays } from "date-fns";

interface AnalyticsDashboardProps {
  tasks: Task[];
  categories: Category[];
}

export function AnalyticsDashboard({ tasks, categories }: AnalyticsDashboardProps) {
  const priorityData = useMemo(() => {
    const counts = { high: 0, medium: 0, low: 0 };
    tasks.forEach(t => {
      if (!t.completed) counts[t.priority]++;
    });
    return [
      { name: "High", value: counts.high, color: "hsl(var(--destructive))" },
      { name: "Medium", value: counts.medium, color: "hsl(38, 92%, 50%)" },
      { name: "Low", value: counts.low, color: "hsl(142, 71%, 45%)" },
    ].filter(d => d.value > 0);
  }, [tasks]);

  const categoryData = useMemo(() => {
    const counts: Record<string, number> = { Uncategorized: 0 };
    categories.forEach(c => counts[c.name] = 0);
    
    tasks.forEach(t => {
      if (!t.completed) {
        const cat = categories.find(c => c.id === t.category_id);
        const name = cat?.name || "Uncategorized";
        counts[name] = (counts[name] || 0) + 1;
      }
    });

    return Object.entries(counts)
      .filter(([, v]) => v > 0)
      .map(([name, value], i) => ({
        name,
        value,
        color: `hsl(${175 + i * 30}, 60%, ${40 + i * 5}%)`
      }));
  }, [tasks, categories]);

  const completionData = useMemo(() => {
    const last7Days = eachDayOfInterval({
      start: subDays(new Date(), 6),
      end: new Date()
    });

    return last7Days.map(day => {
      const dayStr = format(day, "yyyy-MM-dd");
      const completed = tasks.filter(t => 
        t.completed && t.due_date === dayStr
      ).length;
      const created = tasks.filter(t => 
        format(parseISO(t.created_at), "yyyy-MM-dd") === dayStr
      ).length;

      return {
        day: format(day, "EEE"),
        completed,
        created
      };
    });
  }, [tasks]);

  const weeklyStats = useMemo(() => {
    const completed = tasks.filter(t => t.completed).length;
    const pending = tasks.filter(t => !t.completed).length;
    const total = tasks.length;
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    return { completed, pending, total, completionRate };
  }, [tasks]);

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <BarChart3 className="h-4 w-4" />
          Analytics
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[700px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Task Analytics Dashboard
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 mt-4">
          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-3">
            <Card className="p-3 text-center">
              <p className="text-2xl font-bold text-primary">{weeklyStats.total}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </Card>
            <Card className="p-3 text-center">
              <p className="text-2xl font-bold text-green-500">{weeklyStats.completed}</p>
              <p className="text-xs text-muted-foreground">Done</p>
            </Card>
            <Card className="p-3 text-center">
              <p className="text-2xl font-bold text-yellow-500">{weeklyStats.pending}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </Card>
            <Card className="p-3 text-center">
              <p className="text-2xl font-bold text-primary">{weeklyStats.completionRate}%</p>
              <p className="text-xs text-muted-foreground">Rate</p>
            </Card>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Priority Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <PieChartIcon className="h-4 w-4" />
                  By Priority
                </CardTitle>
              </CardHeader>
              <CardContent>
                {priorityData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie
                        data={priorityData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {priorityData.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-center text-muted-foreground py-10 text-sm">No pending tasks</p>
                )}
              </CardContent>
            </Card>

            {/* Category Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  By Category
                </CardTitle>
              </CardHeader>
              <CardContent>
                {categoryData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={180}>
                    <BarChart data={categoryData} layout="vertical">
                      <XAxis type="number" hide />
                      <YAxis type="category" dataKey="name" width={80} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                        {categoryData.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="text-center text-muted-foreground py-10 text-sm">No data</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Weekly Activity */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Last 7 Days Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={completionData}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                  <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="completed" 
                    stroke="hsl(142, 71%, 45%)" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(142, 71%, 45%)" }}
                    name="Completed"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="created" 
                    stroke="hsl(175, 60%, 42%)" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(175, 60%, 42%)" }}
                    name="Created"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
