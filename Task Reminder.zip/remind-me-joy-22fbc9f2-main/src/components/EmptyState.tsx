import { ClipboardList, CheckCircle2, Calendar } from "lucide-react";
import { FilterType } from "@/types/task";

interface EmptyStateProps {
  filter: FilterType;
}

const emptyStates = {
  all: {
    icon: ClipboardList,
    title: "No tasks yet",
    description: "Create your first task to get started",
  },
  today: {
    icon: Calendar,
    title: "Nothing due today",
    description: "Enjoy your free day or add a new task",
  },
  upcoming: {
    icon: Calendar,
    title: "No upcoming tasks",
    description: "You're all caught up!",
  },
  completed: {
    icon: CheckCircle2,
    title: "No completed tasks",
    description: "Complete a task to see it here",
  },
};

export const EmptyState = ({ filter }: EmptyStateProps) => {
  const { icon: Icon, title, description } = emptyStates[filter];

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center animate-fade-in">
      <div className="p-4 rounded-full bg-muted mb-4">
        <Icon className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-medium text-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground mt-1">{description}</p>
    </div>
  );
};
