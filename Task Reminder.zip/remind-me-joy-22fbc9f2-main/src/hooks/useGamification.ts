import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { toast as sonnerToast } from "sonner";

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  points_required: number | null;
  streak_required: number | null;
  tasks_required: number | null;
}

export interface UserAchievement {
  id: string;
  achievement_id: string;
  unlocked_at: string;
  achievement?: Achievement;
}

export interface GamificationStats {
  total_points: number;
  current_streak: number;
  longest_streak: number;
  tasks_completed_today: number;
  last_activity_date: string | null;
}

export const useGamification = (userId: string | null) => {
  const [stats, setStats] = useState<GamificationStats>({
    total_points: 0,
    current_streak: 0,
    longest_streak: 0,
    tasks_completed_today: 0,
    last_activity_date: null,
  });
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch user gamification stats
  const fetchStats = useCallback(async () => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("total_points, current_streak, longest_streak, tasks_completed_today, last_activity_date")
        .eq("user_id", userId)
        .single();

      if (error) throw error;
      if (data) {
        setStats({
          total_points: data.total_points || 0,
          current_streak: data.current_streak || 0,
          longest_streak: data.longest_streak || 0,
          tasks_completed_today: data.tasks_completed_today || 0,
          last_activity_date: data.last_activity_date,
        });
      }
    } catch (error: any) {
      console.error("Error fetching gamification stats:", error);
    }
  }, [userId]);

  // Fetch all achievements
  const fetchAchievements = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from("achievements")
        .select("*")
        .order("name");

      if (error) throw error;
      setAchievements(data || []);
    } catch (error: any) {
      console.error("Error fetching achievements:", error);
    }
  }, []);

  // Fetch user's unlocked achievements
  const fetchUserAchievements = useCallback(async () => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from("user_achievements")
        .select("*, achievement:achievements(*)")
        .eq("user_id", userId);

      if (error) throw error;
      setUserAchievements(data || []);
    } catch (error: any) {
      console.error("Error fetching user achievements:", error);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (userId) {
      fetchStats();
      fetchAchievements();
      fetchUserAchievements();
    } else {
      setLoading(false);
    }
  }, [userId, fetchStats, fetchAchievements, fetchUserAchievements]);

  // Award points and check for new achievements
  const awardPoints = useCallback(async (points: number, reason: string) => {
    if (!userId) return;

    try {
      const today = new Date().toISOString().split("T")[0];
      const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
      
      // Calculate new streak
      let newStreak = stats.current_streak;
      let newTasksToday = stats.tasks_completed_today;
      
      if (stats.last_activity_date === today) {
        // Same day, just increment tasks
        newTasksToday += 1;
      } else if (stats.last_activity_date === yesterday) {
        // Consecutive day, increment streak
        newStreak += 1;
        newTasksToday = 1;
      } else {
        // Streak broken, reset to 1
        newStreak = 1;
        newTasksToday = 1;
      }

      const newPoints = stats.total_points + points;
      const newLongestStreak = Math.max(stats.longest_streak, newStreak);

      // Update profile
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          total_points: newPoints,
          current_streak: newStreak,
          longest_streak: newLongestStreak,
          tasks_completed_today: newTasksToday,
          last_activity_date: today,
        })
        .eq("user_id", userId);

      if (updateError) throw updateError;

      // Update local state
      setStats({
        total_points: newPoints,
        current_streak: newStreak,
        longest_streak: newLongestStreak,
        tasks_completed_today: newTasksToday,
        last_activity_date: today,
      });

      // Show points earned toast
      sonnerToast.success(`+${points} points!`, {
        description: reason,
      });

      // Check for new achievements
      await checkAndUnlockAchievements(newPoints, newStreak, newTasksToday);
    } catch (error: any) {
      console.error("Error awarding points:", error);
    }
  }, [userId, stats]);

  // Check and unlock achievements
  const checkAndUnlockAchievements = useCallback(async (
    totalPoints: number,
    currentStreak: number,
    tasksToday: number
  ) => {
    if (!userId) return;

    // Get total completed tasks count
    const { data: taskData } = await supabase
      .from("tasks")
      .select("id")
      .eq("user_id", userId)
      .eq("completed", true);

    const totalCompletedTasks = taskData?.length || 0;
    const unlockedIds = userAchievements.map((ua) => ua.achievement_id);

    for (const achievement of achievements) {
      if (unlockedIds.includes(achievement.id)) continue;

      let shouldUnlock = false;

      if (achievement.points_required && totalPoints >= achievement.points_required) {
        shouldUnlock = true;
      } else if (achievement.streak_required && currentStreak >= achievement.streak_required) {
        shouldUnlock = true;
      } else if (achievement.tasks_required && totalCompletedTasks >= achievement.tasks_required) {
        shouldUnlock = true;
      }

      if (shouldUnlock) {
        try {
          const { error } = await supabase.from("user_achievements").insert({
            user_id: userId,
            achievement_id: achievement.id,
          });

          if (!error) {
            sonnerToast.success(`🏆 Achievement Unlocked!`, {
              description: `${achievement.name}: ${achievement.description}`,
              duration: 5000,
            });

            // Refresh user achievements
            fetchUserAchievements();
          }
        } catch (error) {
          console.error("Error unlocking achievement:", error);
        }
      }
    }
  }, [userId, achievements, userAchievements, fetchUserAchievements]);

  const unlockedAchievementIds = userAchievements.map((ua) => ua.achievement_id);

  return {
    stats,
    achievements,
    userAchievements,
    unlockedAchievementIds,
    loading,
    awardPoints,
    refetch: () => {
      fetchStats();
      fetchUserAchievements();
    },
  };
};
