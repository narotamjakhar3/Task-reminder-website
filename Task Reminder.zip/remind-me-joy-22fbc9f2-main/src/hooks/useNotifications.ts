import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface AppNotification {
  id: string;
  type: "task_due" | "task_completed" | "task_created" | "reminder";
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  taskId?: string;
}

export function useNotifications(userId: string | null) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>("default");
  const [pushEnabled, setPushEnabled] = useState(false);

  // Check push notification permission
  useEffect(() => {
    if ("Notification" in window) {
      setPushPermission(Notification.permission);
      setPushEnabled(Notification.permission === "granted");
    }
  }, []);

  // Request push notification permission
  const requestPushPermission = useCallback(async () => {
    if (!("Notification" in window)) {
      toast.error("Push notifications not supported in this browser");
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      setPushPermission(permission);
      setPushEnabled(permission === "granted");
      
      if (permission === "granted") {
        toast.success("Push notifications enabled!");
        // Register service worker
        if ("serviceWorker" in navigator) {
          try {
            await navigator.serviceWorker.register("/sw.js");
            console.log("Service worker registered");
          } catch (err) {
            console.error("Service worker registration failed:", err);
          }
        }
        return true;
      } else {
        toast.error("Push notification permission denied");
        return false;
      }
    } catch (error) {
      console.error("Error requesting notification permission:", error);
      return false;
    }
  }, []);

  // Send a push notification
  const sendPushNotification = useCallback((title: string, options?: NotificationOptions) => {
    if (pushPermission === "granted" && document.hidden) {
      try {
        new Notification(title, {
          icon: "/favicon.ico",
          badge: "/favicon.ico",
          ...options,
        });
      } catch (err) {
        console.error("Error sending notification:", err);
      }
    }
  }, [pushPermission]);

  // Add in-app notification
  const addNotification = useCallback((
    type: AppNotification["type"],
    title: string,
    message: string,
    taskId?: string
  ) => {
    const newNotification: AppNotification = {
      id: crypto.randomUUID(),
      type,
      title,
      message,
      timestamp: new Date(),
      read: false,
      taskId,
    };

    setNotifications(prev => [newNotification, ...prev].slice(0, 50));

    // Also send push notification if enabled and tab is not focused
    if (pushEnabled) {
      sendPushNotification(title, { body: message, tag: newNotification.id });
    }

    return newNotification;
  }, [pushEnabled, sendPushNotification]);

  // Mark notification as read
  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  }, []);

  // Mark all as read
  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  // Clear all notifications
  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Listen for real-time task updates
  useEffect(() => {
    if (!userId) {
      console.log("No userId, skipping realtime subscription");
      return;
    }

    console.log("Setting up realtime subscription for user:", userId);

    const channel = supabase
      .channel("task-notifications")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "tasks",
        },
        (payload) => {
          console.log("Task INSERT event received:", payload);
          const task = payload.new as any;
          if (task.user_id === userId) {
            addNotification(
              "task_created",
              "New Task Created",
              `"${task.title}" has been added to your tasks`,
              task.id
            );
            toast.success("Task created!");
          }
        }
      )
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "tasks",
        },
        (payload) => {
          console.log("Task UPDATE event received:", payload);
          const task = payload.new as any;
          const oldTask = payload.old as any;
          
          if (task.user_id === userId && task.completed && !oldTask.completed) {
            addNotification(
              "task_completed",
              "Task Completed! 🎉",
              `You completed "${task.title}"`,
              task.id
            );
          }
        }
      )
      .subscribe((status) => {
        console.log("Realtime subscription status:", status);
        if (status === "SUBSCRIBED") {
          console.log("Successfully subscribed to task notifications");
        } else if (status === "CHANNEL_ERROR") {
          console.error("Failed to subscribe to task notifications");
        }
      });

    return () => {
      console.log("Cleaning up realtime subscription");
      supabase.removeChannel(channel);
    };
  }, [userId, addNotification]);

  // Check for due tasks periodically
  useEffect(() => {
    if (!userId || !pushEnabled) return;

    const checkDueTasks = async () => {
      const now = new Date();
      const { data: tasks } = await supabase
        .from("tasks")
        .select("id, title, due_date, due_time")
        .eq("user_id", userId)
        .eq("completed", false);

      if (tasks) {
        tasks.forEach(task => {
          const dueDate = new Date(task.due_date);
          const today = new Date();
          
          // Check if task is due today
          if (
            dueDate.toDateString() === today.toDateString() &&
            task.due_time
          ) {
            const [hours, minutes] = task.due_time.split(":").map(Number);
            const dueTime = new Date(today);
            dueTime.setHours(hours, minutes, 0, 0);
            
            // If due time is within 15 minutes
            const timeDiff = dueTime.getTime() - now.getTime();
            if (timeDiff > 0 && timeDiff <= 15 * 60 * 1000) {
              addNotification(
                "task_due",
                "Task Due Soon! ⏰",
                `"${task.title}" is due in ${Math.ceil(timeDiff / 60000)} minutes`,
                task.id
              );
            }
          }
        });
      }
    };

    // Check every 5 minutes
    const interval = setInterval(checkDueTasks, 5 * 60 * 1000);
    checkDueTasks(); // Initial check

    return () => clearInterval(interval);
  }, [userId, pushEnabled, addNotification]);

  const unreadCount = notifications.filter(n => !n.read).length;

  return {
    notifications,
    unreadCount,
    pushPermission,
    pushEnabled,
    requestPushPermission,
    addNotification,
    markAsRead,
    markAllAsRead,
    clearAll,
    sendPushNotification,
  };
}
