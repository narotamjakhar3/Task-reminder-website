import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Task, Category, FilterType, Priority, RecurrenceType } from "@/types/task";
import { isToday, isFuture, addDays, addWeeks, addMonths, parseISO } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export const useTasks = (userId: string | null) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filter, setFilter] = useState<FilterType>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Fetch tasks
  const fetchTasks = useCallback(async () => {
    if (!userId) return;
    
    try {
      const { data, error } = await supabase
        .from("tasks")
        .select("*, category:categories(*)")
        .eq("user_id", userId)
        .order("due_date", { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error: any) {
      toast({ title: "Error fetching tasks", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [userId, toast]);

  // Fetch categories
  const fetchCategories = useCallback(async () => {
    if (!userId) return;

    try {
      const { data, error } = await supabase
        .from("categories")
        .select("*")
        .eq("user_id", userId)
        .order("name");

      if (error) throw error;
      setCategories(data || []);
    } catch (error: any) {
      toast({ title: "Error fetching categories", description: error.message, variant: "destructive" });
    }
  }, [userId, toast]);

  useEffect(() => {
    if (userId) {
      fetchTasks();
      fetchCategories();
    } else {
      setTasks([]);
      setCategories([]);
      setLoading(false);
    }
  }, [userId, fetchTasks, fetchCategories]);

  // Add task
  const addTask = useCallback(async (task: {
    title: string;
    description?: string;
    due_date: Date;
    due_time?: string;
    priority: Priority;
    category_id?: string;
    recurrence: RecurrenceType;
  }) => {
    if (!userId) return;

    try {
      const { error } = await supabase.from("tasks").insert({
        user_id: userId,
        title: task.title,
        description: task.description,
        due_date: task.due_date.toISOString(),
        due_time: task.due_time,
        priority: task.priority,
        category_id: task.category_id,
        recurrence: task.recurrence,
      });

      if (error) throw error;
      toast({ title: "Task created successfully" });
      fetchTasks();
    } catch (error: any) {
      toast({ title: "Error creating task", description: error.message, variant: "destructive" });
    }
  }, [userId, fetchTasks, toast]);

  // Update task
  const updateTask = useCallback(async (id: string, updates: Partial<Task>) => {
    if (!userId) return;

    try {
      const { error } = await supabase
        .from("tasks")
        .update(updates)
        .eq("id", id)
        .eq("user_id", userId);

      if (error) throw error;
      toast({ title: "Task updated successfully" });
      fetchTasks();
    } catch (error: any) {
      toast({ title: "Error updating task", description: error.message, variant: "destructive" });
    }
  }, [userId, fetchTasks, toast]);

  // Toggle task completion with recurring support
  const toggleTask = useCallback(async (id: string) => {
    if (!userId) return;
    
    const task = tasks.find((t) => t.id === id);
    if (!task) return;

    const newCompleted = !task.completed;

    try {
      // Update current task
      await supabase
        .from("tasks")
        .update({ completed: newCompleted })
        .eq("id", id)
        .eq("user_id", userId);

      // If completing a recurring task, create the next occurrence
      if (newCompleted && task.recurrence !== "none") {
        const currentDueDate = parseISO(task.due_date);
        let nextDueDate: Date;

        switch (task.recurrence) {
          case "daily":
            nextDueDate = addDays(currentDueDate, 1);
            break;
          case "weekly":
            nextDueDate = addWeeks(currentDueDate, 1);
            break;
          case "monthly":
            nextDueDate = addMonths(currentDueDate, 1);
            break;
          default:
            nextDueDate = currentDueDate;
        }

        await supabase.from("tasks").insert({
          user_id: userId,
          title: task.title,
          description: task.description,
          due_date: nextDueDate.toISOString(),
          due_time: task.due_time,
          priority: task.priority,
          category_id: task.category_id,
          recurrence: task.recurrence,
        });
      }

      fetchTasks();
    } catch (error: any) {
      toast({ title: "Error updating task", description: error.message, variant: "destructive" });
    }
  }, [userId, tasks, fetchTasks, toast]);

  // Delete task
  const deleteTask = useCallback(async (id: string) => {
    if (!userId) return;

    try {
      const { error } = await supabase
        .from("tasks")
        .delete()
        .eq("id", id)
        .eq("user_id", userId);

      if (error) throw error;
      toast({ title: "Task deleted successfully" });
      fetchTasks();
    } catch (error: any) {
      toast({ title: "Error deleting task", description: error.message, variant: "destructive" });
    }
  }, [userId, fetchTasks, toast]);

  // Add category
  const addCategory = useCallback(async (name: string, color: string) => {
    if (!userId) return;

    try {
      const { error } = await supabase.from("categories").insert({
        user_id: userId,
        name,
        color,
      });

      if (error) throw error;
      toast({ title: "Category created successfully" });
      fetchCategories();
    } catch (error: any) {
      toast({ title: "Error creating category", description: error.message, variant: "destructive" });
    }
  }, [userId, fetchCategories, toast]);

  // Delete category
  const deleteCategory = useCallback(async (id: string) => {
    if (!userId) return;

    try {
      const { error } = await supabase
        .from("categories")
        .delete()
        .eq("id", id)
        .eq("user_id", userId);

      if (error) throw error;
      toast({ title: "Category deleted successfully" });
      fetchCategories();
      fetchTasks();
    } catch (error: any) {
      toast({ title: "Error deleting category", description: error.message, variant: "destructive" });
    }
  }, [userId, fetchCategories, fetchTasks, toast]);

  // Filter and search tasks
  const filteredTasks = tasks.filter((task) => {
    const dueDate = parseISO(task.due_date);
    
    // Filter by type
    let passesFilter = true;
    switch (filter) {
      case "today":
        passesFilter = isToday(dueDate) && !task.completed;
        break;
      case "upcoming":
        passesFilter = isFuture(dueDate) && !task.completed;
        break;
      case "completed":
        passesFilter = task.completed;
        break;
    }

    // Filter by category
    if (selectedCategory && task.category_id !== selectedCategory) {
      passesFilter = false;
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const matchesSearch = 
        task.title.toLowerCase().includes(query) ||
        task.description?.toLowerCase().includes(query);
      if (!matchesSearch) passesFilter = false;
    }

    return passesFilter;
  });

  const stats = {
    total: tasks.length,
    completed: tasks.filter((t) => t.completed).length,
    pending: tasks.filter((t) => !t.completed).length,
    todayTasks: tasks.filter((t) => isToday(parseISO(t.due_date)) && !t.completed).length,
  };

  return {
    tasks: filteredTasks,
    allTasks: tasks,
    categories,
    filter,
    setFilter,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    addTask,
    updateTask,
    toggleTask,
    deleteTask,
    addCategory,
    deleteCategory,
    stats,
    loading,
    refetch: fetchTasks,
  };
};
