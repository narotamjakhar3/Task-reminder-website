import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface Subtask {
  id: string;
  task_id: string;
  user_id: string;
  title: string;
  completed: boolean;
  created_at: string;
  updated_at: string;
}

export const useSubtasks = (userId: string | null, taskId: string | null) => {
  const [subtasks, setSubtasks] = useState<Subtask[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Fetch subtasks for a specific task
  const fetchSubtasks = useCallback(async () => {
    if (!userId || !taskId) {
      setSubtasks([]);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("subtasks")
        .select("*")
        .eq("task_id", taskId)
        .eq("user_id", userId)
        .order("created_at", { ascending: true });

      if (error) throw error;
      setSubtasks(data || []);
    } catch (error: any) {
      console.error("Error fetching subtasks:", error);
    } finally {
      setLoading(false);
    }
  }, [userId, taskId]);

  useEffect(() => {
    fetchSubtasks();
  }, [fetchSubtasks]);

  // Add subtask
  const addSubtask = useCallback(async (title: string) => {
    if (!userId || !taskId) return;

    try {
      const { error } = await supabase.from("subtasks").insert({
        task_id: taskId,
        user_id: userId,
        title,
      });

      if (error) throw error;
      fetchSubtasks();
    } catch (error: any) {
      toast({ title: "Error adding subtask", description: error.message, variant: "destructive" });
    }
  }, [userId, taskId, fetchSubtasks, toast]);

  // Toggle subtask completion
  const toggleSubtask = useCallback(async (subtaskId: string) => {
    if (!userId) return;

    const subtask = subtasks.find((s) => s.id === subtaskId);
    if (!subtask) return;

    try {
      const { error } = await supabase
        .from("subtasks")
        .update({ completed: !subtask.completed })
        .eq("id", subtaskId)
        .eq("user_id", userId);

      if (error) throw error;
      fetchSubtasks();
    } catch (error: any) {
      toast({ title: "Error updating subtask", description: error.message, variant: "destructive" });
    }
  }, [userId, subtasks, fetchSubtasks, toast]);

  // Delete subtask
  const deleteSubtask = useCallback(async (subtaskId: string) => {
    if (!userId) return;

    try {
      const { error } = await supabase
        .from("subtasks")
        .delete()
        .eq("id", subtaskId)
        .eq("user_id", userId);

      if (error) throw error;
      fetchSubtasks();
    } catch (error: any) {
      toast({ title: "Error deleting subtask", description: error.message, variant: "destructive" });
    }
  }, [userId, fetchSubtasks, toast]);

  const completedCount = subtasks.filter((s) => s.completed).length;
  const totalCount = subtasks.length;
  const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  return {
    subtasks,
    loading,
    addSubtask,
    toggleSubtask,
    deleteSubtask,
    completedCount,
    totalCount,
    progress,
    refetch: fetchSubtasks,
  };
};
