export type Priority = "high" | "medium" | "low";
export type RecurrenceType = "none" | "daily" | "weekly" | "monthly";

export interface Category {
  id: string;
  user_id: string;
  name: string;
  color: string;
  created_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description?: string;
  due_date: string;
  due_time?: string;
  priority: Priority;
  completed: boolean;
  category_id?: string;
  recurrence: RecurrenceType;
  created_at: string;
  updated_at: string;
  category?: Category;
}

export type FilterType = "all" | "today" | "upcoming" | "completed";
