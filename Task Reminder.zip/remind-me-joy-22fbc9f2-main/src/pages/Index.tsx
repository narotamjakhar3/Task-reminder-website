import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useTasks } from "@/hooks/useTasks";
import { useNotifications } from "@/hooks/useNotifications";
import { useGamification } from "@/hooks/useGamification";
import { Task } from "@/types/task";
import { TaskCard } from "@/components/TaskCard";
import { TaskForm } from "@/components/TaskForm";
import { StatsCard } from "@/components/StatsCard";
import { FilterTabs } from "@/components/FilterTabs";
import { ProgressRing } from "@/components/ProgressRing";
import { EmptyState } from "@/components/EmptyState";
import { CategoryManager } from "@/components/CategoryManager";
import { SearchBar } from "@/components/SearchBar";
import { AnalyticsDashboard } from "@/components/AnalyticsDashboard";
import { EmailReminder } from "@/components/EmailReminder";
import { NotificationCenter } from "@/components/NotificationCenter";
import { ThemeToggle } from "@/components/ThemeToggle";
import { GamificationPanel } from "@/components/GamificationPanel";
import { Button } from "@/components/ui/button";
import { ListTodo, CheckCircle2, Clock, CalendarDays, Bell, LogOut, Loader2 } from "lucide-react";
import { isToday, isFuture, parseISO } from "date-fns";

const Index = () => {
  const { user, loading: authLoading, signOut } = useAuth();
  const navigate = useNavigate();
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const {
    tasks,
    allTasks,
    categories,
    filter,
    setFilter,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    addTask,
    updateTask,
    toggleTask,
    deleteTask,
    addCategory,
    deleteCategory,
    stats,
    loading: tasksLoading,
  } = useTasks(user?.id ?? null);

  const {
    notifications,
    unreadCount,
    pushEnabled,
    requestPushPermission,
    markAsRead,
    markAllAsRead,
    clearAll,
  } = useNotifications(user?.id ?? null);

  const { awardPoints } = useGamification(user?.id ?? null);

  // Redirect to auth if not logged in
  if (!authLoading && !user) {
    navigate("/auth");
    return null;
  }

  if (authLoading || tasksLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="mt-4 text-muted-foreground">Loading your tasks...</p>
        </div>
      </div>
    );
  }

  const progress = stats.total > 0 ? (stats.completed / stats.total) * 100 : 0;

  const filterCounts = {
    all: allTasks.length,
    today: allTasks.filter((t) => isToday(parseISO(t.due_date)) && !t.completed).length,
    upcoming: allTasks.filter((t) => isFuture(parseISO(t.due_date)) && !t.completed).length,
    completed: allTasks.filter((t) => t.completed).length,
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
  };

  const handleUpdateTask = async (taskData: {
    title: string;
    description?: string;
    due_date: Date;
    due_time?: string;
    priority: any;
    category_id?: string;
    recurrence: any;
  }) => {
    if (editingTask) {
      await updateTask(editingTask.id, {
        title: taskData.title,
        description: taskData.description,
        due_date: taskData.due_date.toISOString(),
        due_time: taskData.due_time,
        priority: taskData.priority,
        category_id: taskData.category_id,
        recurrence: taskData.recurrence,
      });
      setEditingTask(null);
    }
  };

  const handleTaskComplete = () => {
    awardPoints(10, "Task completed");
  };

  const handleSubtaskComplete = () => {
    awardPoints(2, "Subtask completed");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl gradient-primary">
                <Bell className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">TaskReminder</h1>
                <p className="text-sm text-muted-foreground">
                  {user?.email}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <GamificationPanel userId={user?.id ?? null} />
              <ThemeToggle />
              <NotificationCenter
                notifications={notifications}
                unreadCount={unreadCount}
                pushEnabled={pushEnabled}
                onRequestPush={requestPushPermission}
                onMarkAsRead={markAsRead}
                onMarkAllAsRead={markAllAsRead}
                onClearAll={clearAll}
              />
              <AnalyticsDashboard tasks={allTasks} categories={categories} />
              <EmailReminder tasks={allTasks} userEmail={user?.email || ""} />
              <TaskForm onSubmit={addTask} categories={categories} />
              <Button variant="outline" size="icon" onClick={handleSignOut}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <section className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="lg:col-span-1 bg-card rounded-xl p-5 shadow-card flex items-center justify-center animate-fade-in">
              <ProgressRing progress={progress} />
            </div>
            <div className="lg:col-span-4 grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatsCard
                title="Total Tasks"
                value={stats.total}
                icon={ListTodo}
                color="primary"
                delay={50}
              />
              <StatsCard
                title="Completed"
                value={stats.completed}
                icon={CheckCircle2}
                color="success"
                delay={100}
              />
              <StatsCard
                title="Pending"
                value={stats.pending}
                icon={Clock}
                color="warning"
                delay={150}
              />
              <StatsCard
                title="Due Today"
                value={stats.todayTasks}
                icon={CalendarDays}
                color="muted"
                delay={200}
              />
            </div>
          </div>
        </section>

        {/* Search and Categories */}
        <section className="mb-6 space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <SearchBar value={searchQuery} onChange={setSearchQuery} />
            </div>
          </div>
          <CategoryManager
            categories={categories}
            onAdd={addCategory}
            onDelete={deleteCategory}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />
        </section>

        {/* Filter Tabs */}
        <section className="mb-6">
          <FilterTabs filter={filter} onChange={setFilter} counts={filterCounts} />
        </section>

        {/* Task List */}
        <section>
          {tasks.length === 0 ? (
            <EmptyState filter={filter} />
          ) : (
            <div className="grid gap-3">
              {tasks
                .sort((a, b) => {
                  if (a.completed !== b.completed) return a.completed ? 1 : -1;
                  return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
                })
                .map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    userId={user?.id ?? null}
                    onToggle={(id) => {
                      toggleTask(id);
                      const t = tasks.find(t => t.id === id);
                      if (t && !t.completed) {
                        handleTaskComplete();
                      }
                    }}
                    onDelete={deleteTask}
                    onEdit={handleEditTask}
                    onSubtaskComplete={handleSubtaskComplete}
                  />
                ))}
            </div>
          )}
        </section>

        {/* Edit Task Dialog */}
        <TaskForm
          onSubmit={handleUpdateTask}
          categories={categories}
          editTask={editingTask}
          open={!!editingTask}
          onClose={() => setEditingTask(null)}
        />
      </main>

      {/* Footer */}
      <footer className="border-t mt-auto py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Built with React & NodeJS Backend • {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
