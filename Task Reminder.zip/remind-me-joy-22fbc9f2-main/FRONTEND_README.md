# TaskReminder Frontend

React.js frontend for the TaskReminder application.

## Technology Stack

- **Framework**: React.js 18
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **UI Components**: shadcn/ui (Radix UI)
- **State Management**: React Query (TanStack Query)
- **Routing**: React Router
- **Form Handling**: React Hook Form + Zod
- **Charts**: Recharts

## Project Structure

```
src/
├── components/           # React components
│   ├── ui/              # shadcn/ui base components
│   ├── TaskCard.tsx     # Individual task display
│   ├── TaskForm.tsx     # Task creation/editing form
│   ├── SearchBar.tsx    # Task search functionality
│   ├── FilterTabs.tsx   # Task filtering tabs
│   ├── CategoryManager.tsx  # Category management
│   ├── SubtaskList.tsx  # Subtask management
│   ├── GamificationPanel.tsx  # Points & achievements
│   ├── ThemeToggle.tsx  # Dark/light mode toggle
│   └── ...
├── hooks/               # Custom React hooks
│   ├── useAuth.ts       # Authentication hook
│   ├── useTasks.ts      # Task management hook
│   ├── useSubtasks.ts   # Subtask management hook
│   ├── useGamification.ts   # Gamification hook
│   └── useNotifications.ts  # Notification hook
├── pages/               # Page components
│   ├── Index.tsx        # Main dashboard
│   ├── Auth.tsx         # Login/signup page
│   └── NotFound.tsx     # 404 page
├── integrations/        # External service integrations
│   └── supabase/        # Supabase client & types
├── types/               # TypeScript type definitions
│   └── task.ts          # Task-related types
├── lib/                 # Utility functions
│   └── utils.ts         # Helper functions
├── App.tsx              # Main App component
├── main.tsx             # Entry point
└── index.css            # Global styles
```

## Features

### Core Features
- ✅ Task Management (CRUD operations)
- ✅ Task Categories with colors
- ✅ Priority levels (High, Medium, Low)
- ✅ Due dates and times
- ✅ Recurring tasks (Daily, Weekly, Monthly)
- ✅ Task search and filtering
- ✅ Subtasks support

### User Experience
- ✅ Responsive design
- ✅ Dark/Light mode
- ✅ Progress tracking
- ✅ Statistics dashboard
- ✅ Email reminders

### Gamification
- ✅ Points system
- ✅ Streak tracking
- ✅ Achievements/Badges

## Installation

1. Navigate to the project root:
   ```bash
   cd taskreminder
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

## Running the Frontend

### Development mode:
```bash
npm run dev
```

The app will start on `http://localhost:5173`

### Build for production:
```bash
npm run build
```

### Preview production build:
```bash
npm run preview
```

## Environment Variables

The frontend uses environment variables for configuration. These are automatically set up when connected to the backend.

| Variable | Description |
|----------|-------------|
| VITE_SUPABASE_URL | Backend URL |
| VITE_SUPABASE_PUBLISHABLE_KEY | Public API key |

## Component Overview

### TaskCard
Displays individual tasks with:
- Title, description, due date
- Priority badge
- Category badge
- Completion toggle
- Edit/Delete actions
- Subtasks (expandable)

### TaskForm
Form for creating/editing tasks with:
- Title and description inputs
- Date and time pickers
- Priority selector
- Category selector
- Recurrence options

### GamificationPanel
Displays user's gamification stats:
- Total points
- Current streak
- Achievements progress

### ThemeToggle
Toggles between light and dark mode themes.

## Styling

The app uses Tailwind CSS with a custom design system:

- **Colors**: Defined in `tailwind.config.ts` and `index.css`
- **Components**: shadcn/ui components with custom variants
- **Responsive**: Mobile-first responsive design

## State Management

- **Server State**: React Query for API data caching
- **Local State**: React useState/useReducer
- **Auth State**: Custom useAuth hook with context

## API Integration

The frontend communicates with the backend via:
- Supabase JavaScript client (direct database access)
- Node.js API endpoints (for additional server-side logic)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

ISC
