
const router = require("express").Router();
const { sendReminder } = require("../controllers/reminder.controller");

router.post("/", sendReminder);

module.exports = router;
