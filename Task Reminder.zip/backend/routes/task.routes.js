
const router = require("express").Router();
const { getTasks } = require("../controllers/task.controller");

router.get("/", getTasks);

module.exports = router;
