
const router = require("express").Router();
const { aiAssistant } = require("../controllers/ai.controller");

router.post("/", aiAssistant);

module.exports = router;
