
const sendReminder = async (req, res, next) => {
  try {
    const { text, time } = req.body;
    res.status(201).json({
      message: "Reminder scheduled successfully",
      text,
      time
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { sendReminder };
