
const aiAssistant = async (req, res, next) => {
  try {
    const { message } = req.body;
    const reply = `AI response for: ${message}`;
    res.status(200).json({ reply });
  } catch (err) {
    next(err);
  }
};

module.exports = { aiAssistant };
