
const supabase = require("../services/supabase.service");

const getTasks = async (req, res, next) => {
  try {
    const { data, error } = await supabase.from("tasks").select("*");
    if (error) throw error;
    res.status(200).json(data);
  } catch (err) {
    next(err);
  }
};

module.exports = { getTasks };
